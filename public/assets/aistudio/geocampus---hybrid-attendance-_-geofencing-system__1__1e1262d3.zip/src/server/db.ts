import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import type {
  UserRecord,
  CampusConfig,
  ClassSession,
  AttendanceRecord,
  AttendanceStatus,
  OdRequest,
  SystemStats,
  UserRole,
} from '../types/index.js';

interface DatabaseSchema {
  users: UserRecord[];
  config: CampusConfig;
  sessions: ClassSession[];
  attendance: AttendanceRecord[];
  od_requests: OdRequest[];
  audit_logs: {
    id: number;
    event: string;
    user_id?: string;
    details: string;
    timestamp: number;
  }[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'geocampus_db.json');

// Ensure directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

let dbData: DatabaseSchema | null = null;

function saveDb(): void {
  if (!dbData) return;
  const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
  fs.writeFileSync(tempFile, JSON.stringify(dbData, null, 2), 'utf-8');
  fs.renameSync(tempFile, DB_FILE);
}

export async function initDb(): Promise<void> {
  if (fs.existsSync(DB_FILE)) {
    try {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      dbData = JSON.parse(raw);
      return;
    } catch (err) {
      console.warn('Failed to parse existing DB file, reinitializing...', err);
    }
  }

  // Initial Seed Data with bcrypt hashed passwords
  const studentHash = await bcrypt.hash('student123', 12);
  const facultyHash = await bcrypt.hash('faculty123', 12);
  const adminHash = await bcrypt.hash('admin123', 12);

  const initialUsers: UserRecord[] = [
    {
      id: 'CIT2026001',
      name: 'Aditya Sharma',
      role: 'student',
      department: 'Computer Science & Engineering',
      email: 'aditya.cit@campus.edu',
      password_hash: studentHash,
    },
    {
      id: 'CIT2026002',
      name: 'Priya Narayanan',
      role: 'student',
      department: 'Computer Science & Engineering',
      email: 'priya.cit@campus.edu',
      password_hash: studentHash,
    },
    {
      id: 'CIT2026003',
      name: 'Kavita Menon',
      role: 'student',
      department: 'Information Technology',
      email: 'kavita.cit@campus.edu',
      password_hash: studentHash,
    },
    {
      id: 'faculty01',
      name: 'Dr. Ramesh Kumar',
      role: 'faculty',
      department: 'Computer Science & Engineering',
      email: 'ramesh.kumar@faculty.campus.edu',
      password_hash: facultyHash,
    },
    {
      id: 'admin01',
      name: 'System Administrator',
      role: 'admin',
      department: 'IT Infrastructure & Security',
      email: 'security.admin@campus.edu',
      password_hash: adminHash,
    },
  ];

  const initialConfig: CampusConfig = {
    id: 1,
    campusName: 'CIT Central Academic Quadrangle',
    lat: 13.0827,
    lon: 80.2707,
    radius: 50, // 50m strict geofence radius
    maxGpsAccuracy: 50,
    allowToleranceMeters: 5,
  };

  const now = Date.now();
  const dayMs = 86400000;

  // Sample realistic past attendance logs
  const initialAttendance: AttendanceRecord[] = [
    {
      id: 1,
      session_id: 101,
      session_token: 'CS301-849201',
      user_id: 'CIT2026001',
      user_name: 'Aditya Sharma',
      course: 'CS301',
      lat: 13.08271,
      lon: 80.27072,
      distance: 3,
      accuracy: 6.2,
      device_id: 'dev_cit_demo_01',
      status: 'Verified',
      created_at: now - dayMs * 2,
    },
    {
      id: 2,
      session_id: 101,
      session_token: 'CS301-849201',
      user_id: 'CIT2026002',
      user_name: 'Priya Narayanan',
      course: 'CS301',
      lat: 13.08282,
      lon: 80.27065,
      distance: 14,
      accuracy: 8.5,
      device_id: 'dev_cit_demo_02',
      status: 'Verified',
      created_at: now - dayMs * 2 + 15000,
    },
    {
      id: 3,
      session_id: 102,
      session_token: 'CS302-194032',
      user_id: 'CIT2026001',
      user_name: 'Aditya Sharma',
      course: 'CS302',
      lat: 13.08269,
      lon: 80.27068,
      distance: 2,
      accuracy: 5.1,
      device_id: 'dev_cit_demo_01',
      status: 'Verified',
      created_at: now - dayMs,
    },
    {
      id: 4,
      session_id: 102,
      session_token: 'CS302-194032',
      user_id: 'CIT2026003',
      user_name: 'Kavita Menon',
      course: 'CS302',
      lat: 13.0845,
      lon: 80.2731,
      distance: 320,
      accuracy: 12.0,
      device_id: 'dev_cit_demo_03',
      status: 'Rejected (Out of Bounds)',
      created_at: now - dayMs + 32000,
    },
  ];

  const initialOd: OdRequest[] = [
    {
      id: 1,
      user_id: 'CIT2026001',
      user_name: 'Aditya Sharma',
      reason: 'National Smart India Hackathon Grand Finale',
      date: new Date(now + dayMs * 3).toISOString().split('T')[0],
      proof_filename: null,
      proof_original_name: 'sih_acceptance_letter.pdf',
      status: 'Pending',
      created_at: now - 3600000 * 5,
    },
    {
      id: 2,
      user_id: 'CIT2026002',
      user_name: 'Priya Narayanan',
      reason: 'State Level Inter-College Basketball Tournament',
      date: new Date(now - dayMs * 4).toISOString().split('T')[0],
      proof_filename: null,
      proof_original_name: 'sports_board_od.pdf',
      status: 'Approved',
      created_at: now - dayMs * 5,
      reviewed_by: 'faculty01',
      decision_notes: 'Approved based on Physical Education Director verification.',
    },
  ];

  dbData = {
    users: initialUsers,
    config: initialConfig,
    sessions: [],
    attendance: initialAttendance,
    od_requests: initialOd,
    audit_logs: [
      {
        id: 1,
        event: 'SYSTEM_INIT',
        details: 'GeoCampus system initialized with default geofence configuration.',
        timestamp: now,
      },
    ],
  };

  saveDb();
}

function getDb(): DatabaseSchema {
  if (!dbData) {
    throw new Error('Database not initialized. Call initDb() first.');
  }
  return dbData;
}

// User Queries
export function findUser(id: string, role?: UserRole): UserRecord | undefined {
  const db = getDb();
  return db.users.find((u) => u.id.toLowerCase() === id.toLowerCase() && (!role || u.role === role));
}

export function getUserPublic(id: string) {
  const user = findUser(id);
  if (!user) return undefined;
  const { password_hash, ...rest } = user;
  return rest;
}

// Config Queries
export function getConfig(): CampusConfig {
  return getDb().config;
}

export function updateConfig(updates: Partial<CampusConfig>): CampusConfig {
  const db = getDb();
  db.config = {
    ...db.config,
    ...updates,
  };
  saveDb();
  return db.config;
}

// Session Queries
export function createSession(
  course: string,
  facultyId: string,
  facultyName: string,
  token: string,
  durationSec: number = 60,
  autoRotate: boolean = false
): ClassSession {
  const db = getDb();
  const now = Date.now();
  const session: ClassSession = {
    id: db.sessions.length + 1,
    token: token.toUpperCase(),
    course: course.toUpperCase(),
    faculty_id: facultyId,
    faculty_name: facultyName,
    created_at: now,
    expires_at: now + durationSec * 1000,
    is_active: true,
    auto_rotate: autoRotate,
  };

  db.sessions.push(session);
  saveDb();
  return session;
}

export function rotateSessionToken(sessionId: number, newToken: string, durationSec: number = 45): ClassSession | null {
  const db = getDb();
  const session = db.sessions.find((s) => s.id === sessionId);
  if (!session) return null;

  session.previous_token = session.token;
  session.token = newToken.toUpperCase();
  session.created_at = Date.now();
  session.expires_at = Date.now() + durationSec * 1000;
  session.is_active = true;

  saveDb();
  return session;
}

export function getSessionByToken(token: string): ClassSession | undefined {
  const db = getDb();
  const upper = token.trim().toUpperCase();
  const now = Date.now();
  // Valid if it matches the current active token, or previous token within grace window (45s after expiration)
  return db.sessions.find((s) => {
    if (s.token === upper && s.expires_at > now) return true;
    if (s.previous_token === upper && now - s.expires_at < 45000) return true;
    return false;
  });
}

export function getActiveSessions(): ClassSession[] {
  const db = getDb();
  const now = Date.now();
  return db.sessions.filter((s) => s.is_active && s.expires_at > now);
}

export function getFacultyActiveSession(facultyId: string): ClassSession | undefined {
  const db = getDb();
  const now = Date.now();
  return db.sessions
    .slice()
    .reverse()
    .find((s) => s.faculty_id === facultyId && s.is_active && s.expires_at > now);
}

// Attendance Queries
export function getAttendanceLogs(role: UserRole, userId: string): AttendanceRecord[] {
  const db = getDb();
  if (role === 'student') {
    return db.attendance
      .filter((a) => a.user_id.toLowerCase() === userId.toLowerCase())
      .sort((a, b) => b.created_at - a.created_at);
  }

  if (role === 'faculty') {
    // Faculty can view attendance for their own sessions
    const facultySessionIds = new Set(
      db.sessions.filter((s) => s.faculty_id === userId).map((s) => s.id)
    );
    return db.attendance
      .filter((a) => facultySessionIds.has(a.session_id) || a.course.startsWith('CS'))
      .sort((a, b) => b.created_at - a.created_at);
  }

  // Admin sees all
  return db.attendance.slice().sort((a, b) => b.created_at - a.created_at);
}

export function hasVerifiedAttendance(sessionId: number, userId: string): boolean {
  const db = getDb();
  return db.attendance.some(
    (a) => a.session_id === sessionId && a.user_id.toLowerCase() === userId.toLowerCase() && a.status === 'Verified'
  );
}

export function getRecentUserCheckins(userId: string, limit: number = 3): AttendanceRecord[] {
  const db = getDb();
  return db.attendance
    .filter((a) => a.user_id.toLowerCase() === userId.toLowerCase())
    .sort((a, b) => b.created_at - a.created_at)
    .slice(0, limit);
}

export function getDeviceAttendanceInSession(sessionId: number, deviceId: string): AttendanceRecord[] {
  const db = getDb();
  return db.attendance.filter((a) => a.session_id === sessionId && a.device_id === deviceId);
}

export function insertAttendance(record: Omit<AttendanceRecord, 'id'>): AttendanceRecord {
  const db = getDb();
  const newRecord: AttendanceRecord = {
    ...record,
    id: db.attendance.length + 1,
  };
  db.attendance.unshift(newRecord);
  saveDb();
  return newRecord;
}

// OD Queries
export function getOdRequests(role: UserRole, userId: string): OdRequest[] {
  const db = getDb();
  if (role === 'student') {
    return db.od_requests
      .filter((r) => r.user_id.toLowerCase() === userId.toLowerCase())
      .sort((a, b) => b.created_at - a.created_at);
  }
  // Faculty & Admin see all
  return db.od_requests.slice().sort((a, b) => b.created_at - a.created_at);
}

export function createOdRequest(
  userId: string,
  userName: string,
  reason: string,
  date: string,
  proofFilename: string | null,
  proofOriginalName: string | null
): OdRequest {
  const db = getDb();
  const newOd: OdRequest = {
    id: db.od_requests.length + 1,
    user_id: userId,
    user_name: userName,
    reason,
    date,
    proof_filename: proofFilename,
    proof_original_name: proofOriginalName,
    status: 'Pending',
    created_at: Date.now(),
  };
  db.od_requests.unshift(newOd);
  saveDb();
  return newOd;
}

export function updateOdDecision(
  id: number,
  decision: 'Approved' | 'Rejected',
  reviewerId: string,
  notes?: string
): OdRequest | null {
  const db = getDb();
  const od = db.od_requests.find((r) => r.id === id);
  if (!od) return null;

  od.status = decision;
  od.reviewed_by = reviewerId;
  if (notes) od.decision_notes = notes;
  saveDb();
  return od;
}

// Stats Queries
export function getSystemStats(role: UserRole, userId: string): SystemStats {
  const db = getDb();
  const now = Date.now();
  const activeSessions = db.sessions.filter((s) => s.is_active && s.expires_at > now).length;
  const pendingOdRequests = db.od_requests.filter((r) => r.status === 'Pending').length;

  let records = db.attendance;
  if (role === 'student') {
    records = db.attendance.filter((a) => a.user_id.toLowerCase() === userId.toLowerCase());
  }

  const totalCheckins = records.length;
  const verifiedCount = records.filter((a) => a.status === 'Verified').length;
  const attendanceRate = totalCheckins > 0 ? Number(((verifiedCount / totalCheckins) * 100).toFixed(1)) : 100;

  // Today check-ins
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const todayCount = records.filter((a) => a.created_at >= startOfDay.getTime()).length;

  // Course breakdown
  const courseMap: Record<string, { verified: number; total: number }> = {};
  for (const r of records) {
    if (!courseMap[r.course]) {
      courseMap[r.course] = { verified: 0, total: 0 };
    }
    courseMap[r.course].total++;
    if (r.status === 'Verified') {
      courseMap[r.course].verified++;
    }
  }

  const courseBreakdown = Object.entries(courseMap).map(([course, stats]) => ({
    course,
    verified: stats.verified,
    total: stats.total,
  }));

  // Recent 7 days activity
  const recentDays: { date: string; verified: number; rejected: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now - i * 86400000);
    const dateStr = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const dayStart = new Date(d).setHours(0, 0, 0, 0);
    const dayEnd = new Date(d).setHours(23, 59, 59, 999);

    const dayRecords = records.filter((r) => r.created_at >= dayStart && r.created_at <= dayEnd);
    const verified = dayRecords.filter((r) => r.status === 'Verified').length;
    const rejected = dayRecords.filter((r) => r.status !== 'Verified').length;

    recentDays.push({ date: dateStr, verified, rejected });
  }

  return {
    attendanceRate,
    totalCheckins,
    verifiedCount,
    activeSessions,
    pendingOdRequests,
    todayCount,
    courseBreakdown,
    recentDays,
  };
}

// Import records with strict validation and deduplication (Bug 13)
export function importAttendanceRecords(records: any[]): {
  total: number;
  imported: number;
  skipped: number;
  errors: string[];
} {
  const db = getDb();
  let imported = 0;
  let skipped = 0;
  const errors: string[] = [];

  const existingKeys = new Set(
    db.attendance.map((a) => `${a.session_token}_${a.user_id.toLowerCase()}_${a.status}`)
  );

  for (let i = 0; i < records.length; i++) {
    const r = records[i];
    const rowNum = i + 1;

    // Validation
    const userId = String(r.userId || r['User ID'] || r.user || '').trim();
    if (!/^[A-Za-z0-9_-]{3,20}$/.test(userId)) {
      errors.push(`Row ${rowNum}: Invalid User ID format ("${userId}").`);
      continue;
    }

    const course = String(r.course || r.Course || r.Subject || 'CS301').trim().toUpperCase();
    const sessionToken = String(r.session_token || r.sessionId || r['Session ID'] || `${course}-IMPORT`).trim().toUpperCase();
    const rawStatus = String(r.status || r.Status || 'Verified').trim();
    const status: AttendanceStatus = rawStatus.includes('Verified') ? 'Verified' : 'Rejected (Out of Bounds)';

    const lat = Number(r.lat || r.latitude || (r.coords ? String(r.coords).split(',')[0] : 13.0827));
    const lon = Number(r.lon || r.longitude || (r.coords ? String(r.coords).split(',')[1] : 80.2707));

    if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
      errors.push(`Row ${rowNum}: Coordinates must be valid numbers.`);
      continue;
    }

    const key = `${sessionToken}_${userId.toLowerCase()}_${status}`;
    if (existingKeys.has(key)) {
      skipped++;
      continue;
    }

    existingKeys.add(key);

    const user = db.users.find((u) => u.id.toLowerCase() === userId.toLowerCase());
    const userName = user ? user.name : `Student (${userId})`;

    const record: AttendanceRecord = {
      id: db.attendance.length + 1,
      session_id: 0,
      session_token: sessionToken,
      user_id: userId,
      user_name: userName,
      course,
      lat,
      lon,
      distance: Number(r.distance ? String(r.distance).replace('m', '') : 10),
      accuracy: Number(r.accuracy || 10),
      device_id: String(r.device_id || 'imported_batch'),
      status,
      created_at: r.created_at || (r.timestamp ? new Date(r.timestamp).getTime() : Date.now()),
    };

    db.attendance.unshift(record);
    imported++;
  }

  saveDb();
  return { total: records.length, imported, skipped, errors };
}

// Audit Logs
export function insertAuditLog(event: string, userId?: string, details: string = ''): void {
  const db = getDb();
  db.audit_logs.unshift({
    id: db.audit_logs.length + 1,
    event,
    user_id: userId,
    details,
    timestamp: Date.now(),
  });
  saveDb();
}
